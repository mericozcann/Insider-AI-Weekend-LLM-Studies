import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	FileReadTool
)





@CrewBase
class PersonalProductivityManagerCrew:
    """PersonalProductivityManager crew"""

    
    @agent
    def project_manager(self) -> Agent:
        
        return Agent(
            config=self.agents_config["project_manager"],
            
            
            tools=[				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def progress_tracker(self) -> Agent:
        
        return Agent(
            config=self.agents_config["progress_tracker"],
            
            
            tools=[				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def productivity_analyst(self) -> Agent:
        
        return Agent(
            config=self.agents_config["productivity_analyst"],
            
            
            tools=[				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    

    
    @task
    def organize_project_structure(self) -> Task:
        return Task(
            config=self.tasks_config["organize_project_structure"],
            markdown=False,
            
            
        )
    
    @task
    def track_project_progress(self) -> Task:
        return Task(
            config=self.tasks_config["track_project_progress"],
            markdown=False,
            
            
        )
    
    @task
    def analyze_productivity_patterns(self) -> Task:
        return Task(
            config=self.tasks_config["analyze_productivity_patterns"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the PersonalProductivityManager crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )

    def _load_response_format(self, name):
        with open(os.path.join(self.base_directory, "config", f"{name}.json")) as f:
            json_schema = json.loads(f.read())

        return SchemaConverter.build(json_schema)
